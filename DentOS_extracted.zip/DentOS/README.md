# DentOS · Phase 1

A French/English local academic workspace with a persistent course catalog. Independent student project, not university-endorsed.

## Run

Install Node.js 24 or newer. Unzip this project into a NEW folder, leaving any existing DentOS repository untouched. In that folder:

```sh
npm start
```

Open http://127.0.0.1:3000. No npm installation, API keys, accounts or paid services are required.

```sh
npm test
npm run check
```

The application uses native browser JavaScript/CSS and Node's built-in HTTP and SQLite modules. No build or lint step is configured, and TypeScript is not used. The browser files are served directly. This intentionally small architecture avoids dependencies for this initial local foundation; a hosted collaborative version needs a separate authentication and hosting decision.

## What works

- Responsive monochrome interface with restrained blue accents.
- French/English interface and persisted language preference.
- Light/dark appearance with initial system preference and persisted selection.
- Course creation, detail view, case-insensitive search and program-year filters.
- SQLite storage across server restarts, source attribution and duplicate-code protection.
- Dashboard counts derived from real catalog records, not mock statistics.
- JSON catalog export, accessible native dialog, form labels and focus outlines.
- Roadmap showing unavailable later phases honestly.

The initial catalog is empty. All course details are user-entered, never claimed to be official or verified. The UI supports adding and exporting courses, not editing, deleting or importing them yet.

## Files

- `server.mjs`: local HTTP server, validation and database API.
- `public/index.html`, `public/app.js`, `public/style.css`: interface, translation dictionaries and theme tokens.
- `migrations/001_catalog.sql`: additive catalog and offering schema plus migration ledger.
- `test/catalog.test.mjs`: API and validation tests using an isolated in-memory database.
- `data/dentos.sqlite`: generated automatically at first startup; excluded from the deliverable.

Courses and offerings are separate tables. Offering management is planned for Phase 2, so historical professor materials are not mixed into the initial catalog. Migration 001 is idempotent; a full incremental migration runner should be added before introducing migration 002.

## Local safety and limitations

The server binds to 127.0.0.1 by default. Do not expose it to a network or production: there is no login, session management, student verification, role authorization or moderation. The host account is the trust boundary for this local release. No student personal information or documents are collected. The API uses parameterized SQL, input limits, same-origin write checks, and a restrictive Content Security Policy. This is not a production security or legal-compliance claim.

Authentication comparison: a managed OpenID Connect provider reduces password and recovery responsibilities but requires external configuration and introduces provider dependence. A maintained self-hosted authentication library provides greater control but requires database-backed sessions, recovery email and additional security testing. Neither is configured here. No custom password security was built. Decide on the provider and verification policy before shared access.

Back up `data/dentos.sqlite` while the application is stopped. JSON export is a catalog copy, not a tested automatic restore mechanism. Preferences reside in browser localStorage. Do not store patient or sensitive student information.

Optional environment variables: `PORT` defaults to 3000, `HOST` defaults to 127.0.0.1, `DATABASE_PATH` defaults to `data/dentos.sqlite`. Keep the default host for personal use.

## Verification

Executed in the build workspace on 2026-10-28:
- `npm test`: 2 tests passed. Covers input bounds, creation/readback, duplicate rejection, cross-origin rejection and protected source-file paths.
- `npm run check`: both JavaScript syntax checks passed.
- Browser preview verified after fixing CLI port/host handling: desktop dashboard in both themes, English translation, theme/language persistence on reload, course dialog opening/cancellation, and preferences navigation. Mobile and full keyboard flows have NOT been verified.

## Roadmap

Phase 1 implemented as a local foundation, with authentication deferred. No PWA installation or offline mode yet. Phase 2 should introduce a maintained authentication provider, authorization tests, course-offering management, private document uploads and version history before collaborative use. Passes, Anki, AI and audio remain future phases. Future hosting, storage, email and AI may have costs and require approval.

No deployment, remote repository or external account was created, following the supplied brief's explicit instruction.
